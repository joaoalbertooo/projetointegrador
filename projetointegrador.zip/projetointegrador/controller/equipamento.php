<?php
    $nome = tdc::r('nome');
    $tipo = tdc::r('tipo');
    $potencia = tdc::r('potencia');
    $eficiencia = tdc::r('eficiencia');
    $obs = tdc::r('obs');
    $tempouso = tdc::r('tempouso');


    $equipamento = tdc::p('td_equipamento');
    $equipamento->nome = $nome;
    $equipamento->tipo = $tipo;
    $equipamento->potencia = $potencia;
    $equipamento->tempouso = $tempouso;
    $equipamento->eficiencia = $eficiencia;
    $equipamento->obs = $obs;
    
    $equipamento->salvar();