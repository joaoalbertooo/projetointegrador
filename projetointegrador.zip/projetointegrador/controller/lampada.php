<?php
    
    // Id do registro
    $id = tdc::r('id');

    // Lê os dados que vêm da requisição GET ou POST
    $descricao = tdc::r('descricao');

    // Cria uma instância da tabela "td_lampada"
    if ($id == 0) {
        $lampada = tdc::p('td_lampada');
    }else{
        $lampada = tdc::p('td_lampada',$id);
    }

    // Atributo valor ao campo "descrição"
    $lampada->descricao = $descricao;

    // Salva a informação no banco de dados
    $lampada->salvar();