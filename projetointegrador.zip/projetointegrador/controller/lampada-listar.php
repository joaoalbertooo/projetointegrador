<?php

    // Retorna todos os registros de uma tabela
    tdc::wj ( tdc::da('td_lampada') );