<?php
$etapa   = $_GET['etapa'];
$sql     = "SELECT pt_br FROM td_apresentacao_traducao WHERE etapa = $etapa;";
$query   = $conn->query($sql);
$result  = $query->fetch();

echo json_encode($result['pt_br']);