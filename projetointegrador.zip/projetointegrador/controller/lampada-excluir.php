<?php
    $id     = $_GET['id'];
    $sql    = "DELETE FROM td_lampada WHERE id = $id;";
    $query  = $conn->exec($sql);